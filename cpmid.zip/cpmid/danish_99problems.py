n = int(input())

x = n % 100
if (x >= 49):
    print(n - x + 99)
elif (n - x == 0):
    print(99)
else:
    print((n//100 - 1)*100 + 99)