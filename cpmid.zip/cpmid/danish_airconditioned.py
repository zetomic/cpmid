def count_non_overlapping_intervals():
    n = int(input())
    if n == 0:
        return 0
        
    # Read all intervals
    intervals = []
    for _ in range(n):
        start, end = map(int, input().split())
        intervals.append((start, end))
    
    # Sort intervals by start time
    intervals.sort()
    
    result = []
    # Add first interval to result
    result.append(intervals[0])
    
    for i in range(1, len(intervals)):
        current = intervals[i]
        last = result[-1]
        
        # Check if current interval overlaps with last interval in result
        if current[0] <= last[1]:
            # Merge intervals by taking the intersection
            # (earliest start, earliest end)
            merged = (last[0], min(last[1], current[1]))
            result[-1] = merged
        else:
            # No overlap, add current interval to result
            result.append(current)
    
    return len(result)

# Execute function
if __name__ == "__main__":
    print(count_non_overlapping_intervals())