def cp(v, time):  # coconuts processed in time
    ans = 0
    for init, cont in v:
        if time >= init:
            ans += 1
            ans += (time - init) // cont
    return ans

def time_taken(v, coconuts):  # min time taken to process coconuts number of coconuts
    l = 0
    r = 10**9
    while l + 1 < r:
        mid = (l + r) // 2
        if cp(v, mid) >= coconuts:
            r = mid
        else:
            l = mid + 1
    if cp(v, l) >= coconuts:
        return l
    else:
        return r

def main():
    total_time = int(input())
    
    n = int(input())
    a = []
    for _ in range(n):
        init, cont = map(int, input().split())
        a.append((init, cont))
    a.sort()
    
    m = int(input())
    b = []
    for _ in range(m):
        init, cont = map(int, input().split())
        b.append((init, cont))
    b.sort()
    
    l = 0
    r = 10**9
    while l < r:
        mid = (l + r) // 2
        if time_taken(a, mid) + time_taken(b, mid) < total_time:
            l = mid + 1
        else:
            r = mid
    
    print(time_taken(a, l))

if __name__ == "__main__":
    main()