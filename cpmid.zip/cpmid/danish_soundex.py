import sys
import re

def phonetic_encoder():
    # Using dictionaries with groups instead of individual mappings
    sound_groups = {
        '1': ['B', 'F', 'P', 'V'],
        '2': ['C', 'G', 'J', 'K', 'Q', 'S', 'X', 'Z'],
        '3': ['D', 'T'],
        '4': ['L'],
        '5': ['M', 'N'],
        '6': ['R']
    }
    
    # Create reverse mapping
    char_to_code = {}
    for code, chars in sound_groups.items():
        for char in chars:
            char_to_code[char] = code
    
    for line in sys.stdin:
        line = line.strip()
        if not line:
            print()
            continue
        
        encoded = []
        last_code = None
        
        # Process first character if valid
        if line[0].upper() in char_to_code:
            code = char_to_code[line[0].upper()]
            encoded.append(code)
            last_code = code
            
        # Process remaining characters
        for char in line[1:]:
            upper_char = char.upper()
            if upper_char in char_to_code:
                code = char_to_code[upper_char]
                # Only add if different from previous code
                if code != last_code:
                    encoded.append(code)
                last_code = code
            else:
                # Reset tracking for non-mapped characters
                last_code = None
                
        print(''.join(encoded))

if __name__ == "__main__":
    phonetic_encoder()