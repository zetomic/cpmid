def calculate_processed_coconuts(machines, available_time):
    """Calculate how many coconuts can be processed within the given time."""
    total_coconuts = 0
    for startup_time, processing_interval in machines:
        if available_time >= startup_time:
            # Process one coconut at startup
            total_coconuts += 1
            
            # Calculate additional coconuts processed after startup
            remaining_time = available_time - startup_time
            additional_coconuts = remaining_time // processing_interval
            total_coconuts += additional_coconuts
    
    return total_coconuts

def find_minimum_processing_time(machines, target_coconuts):
    """Find minimum time required to process a specific number of coconuts."""
    # Binary search boundaries
    lower_bound = 0
    upper_bound = 10**9
    
    # Binary search for the minimum time
    while lower_bound + 1 < upper_bound:
        middle = (lower_bound + upper_bound) // 2
        processed = calculate_processed_coconuts(machines, middle)
        
        if processed >= target_coconuts:
            upper_bound = middle
        else:
            lower_bound = middle + 1
    
    # Check which bound gives us the exact answer
    if calculate_processed_coconuts(machines, lower_bound) >= target_coconuts:
        return lower_bound
    else:
        return upper_bound

def solve_coconut_problem():
    """Solve the coconut processing optimization problem."""
    # Read total available time
    available_time = int(input())
    
    # Read first machine group details
    machine_count_a = int(input())
    machines_a = []
    for _ in range(machine_count_a):
        startup, interval = map(int, input().split())
        machines_a.append((startup, interval))
    machines_a.sort()  # Sort by startup time
    
    # Read second machine group details
    machine_count_b = int(input())
    machines_b = []
    for _ in range(machine_count_b):
        startup, interval = map(int, input().split())
        machines_b.append((startup, interval))
    machines_b.sort()  # Sort by startup time
    
    # Binary search for optimal coconut allocation
    lower = 0
    upper = 10**9
    
    while lower < upper:
        middle = (lower + upper) // 2
        time_for_a = find_minimum_processing_time(machines_a, middle)
        time_for_b = find_minimum_processing_time(machines_b, middle)
        
        if time_for_a + time_for_b < available_time:
            lower = middle + 1
        else:
            upper = middle
    
    # Output time taken by first machine group
    result = find_minimum_processing_time(machines_a, lower)
    print(result)

if __name__ == "__main__":
    solve_coconut_problem()