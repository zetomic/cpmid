def run_game():
    # Read initial parameters
    parameters = input().strip().split()
    player_count = int(parameters[0])
    winning_threshold = int(parameters[1])
    score_updates = int(parameters[2])
    
    # Initialize player data
    player_scores = {}
    already_won = set()
    
    # Register all players
    for _ in range(player_count):
        player_name = input().strip()
        player_scores[player_name] = 0
    
    # Process all score updates
    for _ in range(score_updates):
        update = input().strip().split()
        player_name = update[0]
        points = int(update[1])
        
        # Update player's score
        player_scores[player_name] += points
        
        # Check if player just won
        current_score = player_scores[player_name]
        if current_score >= winning_threshold and player_name not in already_won:
            print(f"{player_name} wins!")
            already_won.add(player_name)
    
    # Check if no one won
    if not already_won:
        print("No winner!")

if __name__ == "__main__":
    run_game()