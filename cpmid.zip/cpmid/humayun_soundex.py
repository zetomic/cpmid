import sys


def encode_name():
    # Different variable naming and structure
    phonetic_map = {
        'B': '1', 'F': '1', 'P': '1', 'V': '1',
        'C': '2', 'G': '2', 'J': '2', 'K': '2', 'Q': '2', 'S': '2', 'X': '2', 'Z': '2',
        'D': '3', 'T': '3',
        'L': '4',
        'M': '5', 'N': '5',
        'R': '6'
    }
    
    for input_line in sys.stdin:
        input_line = input_line.strip().upper()
        if not input_line:
            print()
            continue
            
        result = ""
        previous_code = None
        
        # Process each character
        for char in input_line:
            if char in phonetic_map:
                current_code = phonetic_map[char]
                # Only add a new code if it's different from the previous
                if current_code != previous_code:
                    result += current_code
                previous_code = current_code
            else:
                # Non-mapped character resets the previous code
                previous_code = None
                
        print(result)

if __name__ == "__main__":
    encode_name()