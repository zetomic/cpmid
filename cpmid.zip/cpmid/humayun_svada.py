def calculate_processed_coconuts(monkeys, total_time):
    """Calculate how many coconuts can be processed in the given time."""
    total = 0
    for startup, interval in monkeys:
        if total_time >= startup:
            # First coconut at startup
            total += 1
            # Additional coconuts after startup
            total += (total_time - startup) // interval
    return total

def find_time_for_coconuts(monkeys, coconut_count):
    """Find time needed to process a specific number of coconuts."""
    left = 0
    right = 10**12  # Large upper bound
    
    while left + 1 < right:
        mid = (left + right) // 2
        processed = calculate_processed_coconuts(monkeys, mid)
        
        if processed >= coconut_count:
            right = mid
        else:
            left = mid + 1
    
    # Return the minimum time that processes at least coconut_count
    if calculate_processed_coconuts(monkeys, left) >= coconut_count:
        return left
    return right

def main():
    # Read total time monkeys spent in garden
    total_time = int(input())
    
    # Read first type of monkeys (coconut pickers)
    n = int(input())
    pickers = []
    for _ in range(n):
        a, b = map(int, input().split())
        pickers.append((a, b))
    
    # Read second type of monkeys (coconut openers)
    m = int(input())
    openers = []
    for _ in range(m):
        c, d = map(int, input().split())
        openers.append((c, d))
    
    # Binary search for the number of coconuts
    left = 0
    right = 10**12  # Large upper bound
    
    while left < right:
        mid = (left + right) // 2
        
        # Calculate time needed for each monkey type
        time_for_pickers = find_time_for_coconuts(pickers, mid)
        time_for_openers = find_time_for_coconuts(openers, mid)
        
        # Check if this number of coconuts fits the total time constraint
        if time_for_pickers + time_for_openers <= total_time:
            left = mid + 1
        else:
            right = mid
    
    # Adjust to get the maximum coconuts that fit
    coconut_count = left - 1
    
    # Calculate the time when second type arrives (after first type finishes)
    time_for_pickers = find_time_for_coconuts(pickers, coconut_count)
    
    print(time_for_pickers)

if __name__ == "__main__":
    main()