def find_nearest_99_price(price):
    """
    Find the nearest price ending in 99.
    If two prices are equally distant, return the higher one.
    """
    # Handle special case for very small numbers
    if price < 99:
        return 99
    
    # Calculate the hundreds digit
    hundreds = price // 100
    
    # Calculate the two candidate prices ending in 99
    lower_candidate = hundreds * 100 - 1  # This gives the price ending in 99 below current hundreds
    upper_candidate = (hundreds + 1) * 100 - 1  # This gives the price ending in 99 above current hundreds
    
    # Calculate distances to both candidates
    lower_distance = price - lower_candidate
    upper_distance = upper_candidate - price
    
    # Determine which candidate is closest (or higher in case of tie)
    if lower_distance < upper_distance:
        return lower_candidate
    else:
        return upper_candidate

# Main program
if __name__ == "__main__":
    price = int(input())
    result = find_nearest_99_price(price)
    print(result)