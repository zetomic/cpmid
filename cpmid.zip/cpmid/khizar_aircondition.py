def merge_overlapping_intervals():
    # Read input
    n = int(input())
    intervals = []
    for _ in range(n):
        intervals.append(list(map(int, input().split())))
    
    if not intervals:
        return 0
    
    # Sort by start time
    intervals.sort(key=lambda x: x[0])
    
    # Initialize result with first interval
    result = [intervals[0]]
    
    # Merge overlapping intervals
    for current in intervals[1:]:
        # Get the last interval from result
        prev = result[-1]
        
        # Check if current interval overlaps with previous
        if current[0] <= prev[1]:
            # Update end time of previous interval if needed
            result[-1] = [prev[0], min(prev[1], current[1])]
        else:
            # Add current interval to result if no overlap
            result.append(current)
    
    # Return count of merged intervals
    return len(result)

# Run the program
if __name__ == "__main__":
    print(merge_overlapping_intervals())