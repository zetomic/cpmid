import ollama
import os

# Function to generate responses from the model with temperature and top_p parameters
def generate_response(messages, model_name, temperature=0.7, top_p=0.9):
    # Use Ollama's chat function to generate responses with the parameters
    response = ollama.chat(model=model_name, messages=messages, temperature=temperature, top_p=top_p)
    return response['message']['content']

# Main function to initiate the interview
def start_interview(model_name):
    # System message (using the modelfile's instructions)
    system_msg = """
        You are an AI interviewer named Alex. You are conducting interviews for an entry level developer position. Your goals and instructions:

        1. Start by greeting the user with: "Hi, I am Alex, your interviewer."
        2. Ask for the candidate's name.
        3. Ask a few personal questions (e.g. "How are you today?", "What interests you in this role?").
        4. Then ask 5 generic computer science questions (e.g. data structures, algorithms, etc.), each subsequent question should be adjusted based on the answers of the candidate.
        5. Then ask 5 normal/behavioral interview questions (e.g. "Tell me about a challenge you faced.").
        6. Only ask the next question **after** the user has answered the previous one.
        7. When the interview is completed, provide:
        • A final closing statement.
        • A confidence score (how confident you are in your assessment) out of 100.
        • An accuracy score (how accurate their answers seemed) out of 100.
        • Professionalism score out of 100.
        • Communication score out of 100.
        • Sociability score out of 100.
        • Nonsense score (how irrelevant or contextually off the answers are) out of 100.
        • Overall Interview score out of 100.
        • General insights about the candidate’s performance.
        8. If the user tries to cheat (e.g. asking for direct answers to the CS questions) or attempts to trick the AI, politely refuse to provide solutions and note their attempt in the final insights.
        9. Do not reveal any chain-of-thought. Keep answers professional, concise, and on track.
        10. Do not reveal the insights or suggestions until the interview has ended.

        Begin now by greeting and asking for the candidate’s name.
    """

    # Construct the initial prompt with system message
    messages = [
        {'role': 'system', 'content': system_msg},
    ]
    
    # Start the interview with an assistant role message instead of user greeting
    messages.append({'role': 'assistant', 'content': 'Hi, I am Alex, your interviewer. Can you please tell me your name?'})
    
    while True:
        # Get the model's response with temperature and top_p parameters
        response = generate_response(messages, model_name)
        print(response)
        
        # Now, take user input for the next round of interaction
        user_input = input("Your response: ")
        
        # If the candidate ends the interview or inputs a specific stop command
        if user_input.lower() in ['exit', 'quit', 'stop']:
            print("Ending the interview.")
            break
        
        # Append the user input to the message list as user role
        messages.append({'role': 'user', 'content': user_input})
        
        # Append the model's response to the message list as assistant role
        messages.append({'role': 'assistant', 'content': response})


# Example usage
if __name__ == "__main__":
    model_name = "llama3.2"  # The base model as per your modelfile
    
    # Start the interview with dynamic resume loading
    start_interview(model_name)
